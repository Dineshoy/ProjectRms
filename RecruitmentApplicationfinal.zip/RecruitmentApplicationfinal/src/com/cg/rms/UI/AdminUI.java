package com.cg.rms.UI;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rms.dto.Admin;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CourseService;
import com.cg.rms.service.CourseServiceImpl;

public class AdminUI {
	
	public void adminUimethod() throws RecruitmentException{
		
		CourseService cser = new CourseServiceImpl();
		String role = "admin";
		Scanner sc = new Scanner(System.in);
		System.out.println("********Admin Login Page*********");
		System.out.println();
		System.out.println();
		System.out.println("Enter your login id:");
		String username=sc.next();
		System.out.println("Enter your password:");
		String password=sc.next();
		
		
		try {
			int value=cser.login(username, password, role);
			
			if(value == 2)
			{
				System.out.println("Wrong Credentials.Please try again");
			}
			if(value==1)
			{
				
				System.out.println("welcome Admin");
				
				
			List<Admin> arst =	cser.getAllCandidate();
			System.out.println(arst);
				
			}
		}
			
			catch (RecruitmentException e)
			{
				throw new RecruitmentException("Wrong credentials.Please retry.");
			}
		
	}
	
	}

		
		


