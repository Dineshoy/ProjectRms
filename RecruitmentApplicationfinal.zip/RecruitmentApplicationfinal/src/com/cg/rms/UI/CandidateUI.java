package com.cg.rms.UI;

import java.util.List;
import java.util.Scanner;

import com.cg.rms.dto.JobRequirements;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CourseService;
import com.cg.rms.service.CourseServiceImpl;

public class CandidateUI {
	CandidateBeanPersonal c = new CandidateBeanPersonal();
	CandidateBeanQualification cq = new CandidateBeanQualification();
	CandidateBeanWorkHistory cqq = new CandidateBeanWorkHistory();

public void candidateUimethod() throws RecruitmentException {
		Scanner sc = new Scanner(System.in);
		CourseService cser = new CourseServiceImpl();
		
		String role="candidate";

		
		
		System.out.println("********Candidate Login Page*********");
		System.out.println();
		System.out.println();
		System.out.println("Enter your login id:");
		String username=sc.next();
		System.out.println("Enter your password:");
		String password=sc.next();
		

		
		try {
			int value=cser.login(username, password, role);
			
			if(value == 2)
			{
				System.out.println("Wrong Credentials.Please try again");
				CandidateUI cui = new CandidateUI();
				cui.candidateUimethod();
			}
			if(value==1)
			{
				
				System.out.println("welcome Candidate");
			}
		}
			
			catch (RecruitmentException e)
			{
				System.out.println("Wrong credentials.Please retry.");
			}
		
		
do {
	System.out.println("menu");
System.out.println("1 Add new candidate Details");
/*System.out.println("3. delete a course");*/
System.out.println("2. update candidate Details");
System.out.println("3. search jobs");


System.out.println("4. exit");
int choice = sc.nextInt();
switch (choice) {
case 1:
	
	
	
	  String cid;
	    String qid;
	    String qqid;
		
		
	
	System.out.println("Enter Candidate Personal Details Here");
	System.out.println("\n");
	
	
	System.out.println("enter candidate name");
	c.setCandidate_name(sc.next());
	System.out.println("enter candidate address");
	c.setAddress(sc.next());
	System.out.println("enter DOB");
	
	c.setDOB(sc.next());
	System.out.println("Enter email ID");
	c.setEmail_id(sc.next());
	System.out.println("enter contact no");
	c.setContact_number(sc.next());
	System.out.println("enter marital status");
	c.setMarital_status(sc.next());
	System.out.println("Enter Gender");
	c.setGender(sc.next());
    System.out.println("Enter Passport no");
    c.setPassport_number(sc.next());
    
   if(cser.validateCourse(c)) {
     cid = cser.insertCourse(c);
    System.out.println("Candidate Personal details added with ID"+cid);
   }
    
    System.out.println("Enter Candidate Qualification Details here");
System.out.println("\n");    
    
    
    System.out.println("enter qualification name");
    cq.setQualification_name(sc.next());
	System.out.println("enter specialization area");
	cq.setSpecialization_area(sc.next());
	System.out.println("enter college name");
	cq.setCollege_name(sc.next());
	System.out.println("Enter university name");
	cq.setUniversity_name(sc.next());
	System.out.println("enter year of passing");
	cq.setYear_of_passing(sc.next());
	System.out.println("enter percentage");
	cq.setPercentage(sc.next());
	System.out.println("enter Candidate ID");
	cq.setCandidate_id(sc.next());
	if(cser.validateCandiQualif(cq)){
	qid=cser.insertCandidateBeanQualification(cq);
	System.out.println("candidate qualification details added with ID"+qid);
	}
	
	
	System.out.println("Enter Candidate Work History Details");
	System.out.println("\n");
	
	System.out.println("enter candidate id");
	String candidate_id=sc.next();
	cqq.setCandidate_id(candidate_id);
	System.out.println("enter name of employer");
	String which_employer=sc.next();
	cqq.setWhich_employer(which_employer);
	System.out.println("enter contact person");
	String contact_person=sc.next();
	cqq.setContact_person(contact_person);
	System.out.println("Enter position held");
	String position_held=sc.next();
	cqq.setPosition_held(position_held);
	System.out.println("enter name of company");
	String company_name=sc.next();
	cqq.setCompany_name(company_name);
	System.out.println("enter employment from");
	String employement_from=sc.next();
	cqq.setEmployement_from(employement_from);
	System.out.println("Enter employment to");
	String employement_to=sc.next();
	cqq.setEmployement_to(employement_to);
    System.out.println("Enter reason for leaving the company");
    String reason_for_leaving=sc.next();
    cqq.setReason_for_leaving(reason_for_leaving);
    System.out.println("Enter responsibilities");
    String responsibilities=sc.next();
    cqq.setResponsibilities(responsibilities);
    System.out.println("Enter name of HR representative");
    String hr_rep_name=sc.next();
    cqq.setHr_rep_name(hr_rep_name);
    System.out.println("Enter contact number of HR representative");
    String hr_rep_contact_num=sc.next();
    cqq.setHr_rep_contact_num(hr_rep_contact_num);
    qqid=cser.insertCandidateBeanWorkHistory(cqq);
    System.out.println("Candidate Work-History details added with ID"+qqid);
    
	
 break;

case 2:
	
	System.out.println("1. update Candidate personal Details");
	System.out.println("2.update candidate Qualification Details");
	System.out.println("3.update candidate work details");
	int select=sc.nextInt();
	
	switch (select) {
	case 1:
		
	CandidateBeanPersonal c1 = new CandidateBeanPersonal();
	try {
		boolean b = cser.updateCourse(c1);
		if(b) {
			System.out.println("Details updated for candidate personal");
		}
	} catch (RecruitmentException e) {
		
		e.printStackTrace();
	}
		break;
 case 2:
	
	CandidateBeanQualification c2 = new CandidateBeanQualification();
	try {
		boolean b = cser.updateCandidateBeanQualification(c2);
		if(b) {
			System.out.println("Details updated for candidate Qualifications");
		}
	} catch (RecruitmentException e) {
		
		e.printStackTrace();
	}
		break;
case 3:
	CandidateBeanWorkHistory c3 = new CandidateBeanWorkHistory();
	try {
		boolean b = cser.updatCandidateBeanWorkHistory(c3);
		if(b) {
			System.out.println("Details updated s");
		}
	} catch (RecruitmentException e1) {
		e1.printStackTrace();
	}
	
	break;
	

	default:System.out.println("invalid choice");
		break;
	}
	
	
	break;
case 3:
	System.out.println("*********Welcome to Job Search System**********");
	while(true)
	{		
		JobRequirements jreq= new JobRequirements();
	
		System.out.println("Enter Positions Required");
		jreq.setPosition_required(sc.next());
		System.out.println("Enter Experience Required");
		jreq.setExperience_required(sc.nextLong());
		System.out.println("Enter Qualifications Required");
		jreq.setQualification_required(sc.next());
		System.out.println("Enter Job Location");
		jreq.setJob_location(sc.next());
		try {
			List<JobRequirements> a=cser.searchjobs3(jreq);
			if(a!=null){
				System.out.println("Searched Successfully");
			    System.out.println(a);
			    
			    System.out.println("select an option from below");
			    System.out.println("\n");
			    System.out.println("1. apply for a job");
			    System.out.println("2. exit");
			    int ch;
			 ch  =   sc.nextInt();
			    if(ch==1)
			    {
			    System.out.println("enter ur Candidate_ID");
			    String caid;
			    caid= sc.next();
			    System.out.println("enter the Company ID ");
			  String coid;
			  coid = sc.next();
			  System.out.println("Enter job ID to apply for a job");
			  String jid;
			  jid=sc.next();
			 int q=   cser.apply(caid,coid,jid);
			    
			    if(q==1)
			    {
			    	
			    	System.out.println("you r succesfully applied for a job");
			    }
			    	
			    }
			    
			    else
			    {
			    	
			    System.exit(0);;	
			    	
			    }
			    
			    
			    
			    
			}
		} catch (RecruitmentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
case 4: System.exit(0);

default:System.out.println("invalid choice");
	
	break;
}
} while (true);
	
	}
}